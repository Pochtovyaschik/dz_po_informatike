from ui.Interface import Interface
from storage import load_collection, save_collection

collection = load_collection([])
ui = Interface(collection)

ui.show_menu()

ui.root.mainloop()