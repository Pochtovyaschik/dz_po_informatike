import tkinter as tk
from .components.AppButton import AppButton

class Interface:
    def __init__(self, task_list, width=500, height=500):
        self.root = tk.Tk()
        self.width = width
        self.height = height
        self.root.geometry(f"{width}x{height}")
        self.root.iconbitmap("../assets/icon.ico")
        self.root.title("Pinton Task Manager")
        self.root.configure(bg="black")
        self.task_list = task_list

    def show_menu(self):
        AppButton(self.root, "primary", text="show notes", command=lambda:self.show_tasks()).pack()

    def show_tasks(self):
        text_tasks = tk.Listbox(self.root)
        for task in self.task_list:
            for i in task:
                text_tasks.insert(tk.END, i["name"])
        text_tasks.pack()


