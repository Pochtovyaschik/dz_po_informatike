import tkinter as tk

class AppButton(tk.Button):
    def __init__(self, master, status, text, command):
        super().__init__(master,width=10, height=2, command=command, text=text)
        self.status = status
        self.settings()
        self.configure(background='white', activebackground="grey")
    def settings(self):
        if self.status == "primary":
            self.configure(background='green', activebackground="grey")
        if self.status == "secondary":
            self.configure(background='grey', activebackground="dark grey")
        else:
            self.configure(background='light blue', activebackground="grey")