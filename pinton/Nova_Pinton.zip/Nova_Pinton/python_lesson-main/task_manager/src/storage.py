import json
import os
from config import FILE_NAME_SAVES

file_name = FILE_NAME_SAVES

def load_collection(task_list):
    with open(file_name, "r", encoding='utf-8') as file:
        data = json.load(file)
        task_list.append(data)
    return task_list

def save_collection(task_list):
    with open(file_name, 'w') as file:
        json.dump(task_list, file, ensure_ascii=False, indent=4)